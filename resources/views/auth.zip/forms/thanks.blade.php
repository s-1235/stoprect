@include('header')

<div class="thanks">
    <div class="thanks__container">
        <div class="thanks__block block-modal">
            <h1 class="block-modal__title block-modal__title_red">Thanks you, we have sent it to your email</h1>
        </div>
    </div>
</div>

@include('footer')


<script type="text/javascript">

</script>

