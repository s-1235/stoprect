<!-- crypto PRICING -->

<section id="launchSection">
    <div class="container" >
        <div class="col-11 col-md-8 col-lg-12 mx-auto mt-5">
            <div class="blur-bg" style="min-height: 800px;border-radius: 50px;">
                <div class="d-flex flex-column align-items-center">
                    <h2 class="text-secondary text-uppercase fw-bolder " style="font-size:calc(1.85rem + 1.5vw);">WE ARE LAUNCHING SOON</h2>
                    <div data-timer="2023-05-01" class="d-flex gap-3 gap-lg-5 pt-3">
                        <div class="text-center">
                            <div data-timer-value="days" class="fs-medium fw-bold">00</div>
                            <span class="medium fw-bold">Days</span>
                        </div>
                        <div class="text-center">
                            <div data-timer-value="hours" class="fs-medium fw-bold">00</div>
                            <span class="medium fw-bold">Hours</span>
                        </div>
                        <div class="text-center">
                            <div data-timer-value="minutes" class="fs-medium fw-bold">00</div>
                            <span class="medium fw-bold">Minutes</span>
                        </div>
                        <div class="text-center">
                            <div data-timer-value="seconds" class="fs-medium fw-bold">00</div>
                            <span class="medium fw-bold">Seconds</span>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-column flex-lg-row justify-content-between mt-5" style="padding-left: 30px;padding-right: 30px;">
                    <div class="col-lg-3">
                        <div class="launch_left">
                            <p class="fs-1 fw-semibold">Moving from Telegram to a more <a href="#" class="text-dark" style="text-decoration: underline;">
                                    comfortable user
                                    friendly</a> dashboard
                            </p>
                        </div>
                    </div>
                    <div
                        class="d-flex flex-column gap-3 align-items-center align-items-lg-end col-lg-6 text-md-end text-center">
                        <h3 class="text-primary fs-1 fw-bold text-uppercase">reserve your spot now </h3>
                        <input class="form-control form-control-shadow w-75" type="text" placeholder="Email address">
                        <a href="#"
                            class="form-control btn btn-primary btn-sm btn rounded-pill text-white text-uppercase w-30 fw-semibold">sign
                            up</a>
                        <span class="fs-1 pt-3 fw-semibold">
                            <sub class="text-primary fs-medium fw-bolder">*</sub> maximum <b
                                class="text-primary fs-small fw-bolder">25</b> spots <br>
                            a day available
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="pricingSection">
    <div data-tabs class="col-10 col-lg-8 col-xl-7 mx-auto">
        <div class="row text-center">
            <h2 class="fw-bold fs-small"> Choose Your <span class="text-secondary">Best Plan</span></h2>
            <div class="pricing-btn">
                <div data-tabs-titles class="tabs__navigation">
                    <button type="button" class="tabs__title _tab-active">Monthly</button>
                    <button type="button" class="tabs__title">Yearly</button>
                </div>
            </div>
            <p class="medium fst-italic fw-semibold"><span class="fs-medium text-primary fw-bolder">*</span> We pay 10 most
                expencive crypto world subscribtions and you get it all
                just for minor 1!</p>
        </div>
        <div class="d-flex flex-column align-items-center">
            <div data-tabs-body>
                <div>
                    <div 
                        class="d-flex gap-4 gap-lg-1 flex-column flex-lg-row justify-content-around align-items-center" style="margin-top: 10px;">
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3">
                            <h4 class="pricing-card__header fw-bold">Bronze</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €118</div>
                                <div class="price--new">{{ $prices->where('name',config('constants.plans_id.bronze_monthsub'))->first()->value_2  }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">With this subscription You can
                                follow our <span class="text-secondary">BTC + ETH</span> trades
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit" 
                                        name="selected_plan" 
                                        value="{{config('constants.plans_id.bronze_monthsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3">
                            <h4 class="pricing-card__header fw-bold">Silver</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €178</div>
                                <div class="price--new">{{ $prices->where('name',config('constants.plans_id.silver_monthsub'))->first()->value_2  }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">With this subscription You will be
                                able to access our daily trades <span class="text-secondary">BTC +
                                    ETH
                                    + ALTS</span>
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit"
                                        name="selected_plan"
                                        value="{{config('constants.plans_id.silver_monthsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3 active">
                            <h4 class="pricing-card__header" fw-bold>
                                BIG BALZZ</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €118</div>
                                <div class="price--new">{{ $prices->where('name',config('constants.plans_id.premium_monthsub'))->first()->value_2  }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">
                                <p>With this subscription You will get </p>
                                <ul>
                                    <li>
                                        access to <span>BTC+ETH+ALTS</span>
                                    </li>
                                    <li>
                                        additionally <span>Coin of The Month</span>
                                    </li>
                                    <li>
                                        <span>Emerging Coin</span> early bird info
                                    </li>
                                </ul>
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit"
                                        name="selected_plan"
                                        value="{{config('constants.plans_id.premium_monthsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div>
                    <div 
                        class="d-flex gap-4 gap-lg-1 flex-column flex-lg-row justify-content-around align-items-center" style="margin-top: 10px;">
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3">
                            <h4 class="pricing-card__header fw-bold">Bronze</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €118</div>
                                <div class="price--new">{{ round($prices->where('name',config('constants.plans_id.bronze_yearsub'))->first()->value_2  / 12, 0) }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">With this subscription You can
                                follow our <span class="text-secondary">BTC + ETH</span> trades
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit" 
                                        name="selected_plan" 
                                        value="{{config('constants.plans_id.premium_yearsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3">
                            <h4 class="pricing-card__header fw-bold">Silver</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €178</div>
                                <div class="price--new">{{ round($prices->where('name',config('constants.plans_id.silver_yearsub'))->first()->value_2 / 12,0) }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">With this subscription You will be
                                able to access our daily trades <span class="text-secondary">BTC +
                                    ETH
                                    + ALTS</span>
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit"
                                        name="selected_plan"
                                        value="{{config('constants.plans_id.premium_yearsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                        <div class="pricing-card col-10 col-lg-3 rounded-3 p-3 active">
                            <h4 class="pricing-card__header" fw-bold>
                                BIG BALZZ</h4>
                            <div class="pricing-card__price price p-3">
                                <div class="price--old">NORMALLY €118</div>
                                <div class="price--new">{{ round($prices->where('name',config('constants.plans_id.premium_yearsub'))->first()->value_2 / 12, 0) }}€</div>
                                <div class="price__desc">/month paid monthly</div>
                            </div>
                            <div class="pricing-card__desc">
                                <p>With this subscription You will get </p>
                                <ul>
                                    <li>
                                        access to <span>BTC+ETH+ALTS</span>
                                    </li>
                                    <li>
                                        additionally <span>Coin of The Month</span>
                                    </li>
                                    <li>
                                        <span>Emerging Coin</span> early bird info
                                    </li>
                                </ul>
                            </div>
                            <form method="post" action="{{route('register-subsbcriber')}}" >
                                @csrf
                                <button 
                                        class="pricing-card__btn"
                                        type="submit"
                                        name="selected_plan"
                                        value="{{config('constants.plans_id.premium_yearsub')}}">
                                    Choose plan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex flex-column align-items-center small fw-bold mt-6">
                <p>You will be able to add ratings after the first month of membership.</p>
                <div
                    class="rounded-pill shadow-sm d-inline-flex align-items-start justify-content-center gap-2 pt-2 pb-1 px-5 bg-white btn-sm">
                    <i class="fas fa-user-alt"></i>
                    <span class="fw-bold">188 reviews</span>
                </div>
                <div class="d-flex align-items-center mt-2">
                    <img src="assets/img/Star.svg" alt="">
                    <span>4.7 / 5 </span>
                </div>
            </div>
        </div>
    </div>
</section>