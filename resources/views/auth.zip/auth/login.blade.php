<li>
    <a class="btn btn-light text-primary rounded-pill px-4 shadow-sm d-lg-block my-btn" href="{{route('login')}}?type=1">Login</a>
</li>
{{--<li>--}}
{{--    <a class="btn sign-btn" href="{{route('registration')}}">Sign Up</a>--}}
{{--</li>--}}