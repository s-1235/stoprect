<div>
    <p>
        <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            Help
        </a>
    </p>
    <div class="collapse" id="collapseExample">
        <div class="card card-body">
            <p style="padding: 1em" class="alert-success rounded">
                {!! $helpText  !!}
            </p>
        </div>
    </div>
</div>