@include('header')

@if($user->status !== config('constants.user_status_active') && $user->user_type !== 'ADM') 
    <div style='font-size: 18px;z-index:1000;padding-bottom:35px;' class='alert alert-danger alert-dismissible hideMe' ><button type='button' class='close' data-dismiss='alert'>&times;</button>
        Your Subscription has been Expired</div>
@endif

<style>
    .head {

        background-color: "#cecece";
    }
    .btn-outline-success{
        color:#00bd9c;


    }
    .btn-outline-success:hover{
        background-color:#00bd9c;
        border-color: #00bd9c;

    }
    .btn-outline-success:not(:disabled):not(.disabled).active, .btn-outline-success:not(:disabled):not(.disabled):active, .show>.btn-outline-success.dropdown-toggle {
        color: #fff;
        background-color: #00bd9c;
        border-color: #00bd9c;
    }

    .h-25{
        display:none;
    }

    .cls{
        padding-top:50px;

    }

    .upgrade {
        background-color: #37368c;
        border: none;
        color: white;
        padding: 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        /*font-family:'Arial';*/
        font-size: 12px;
        font-weight:normal;
        margin-top:10px;

    }

    .up {border-radius: 20px;}
</style>

<div class="container">

    @include('dashboard.header-tabs')

    <?php
    use Illuminate\Support\Carbon;
    // if($recs){
    foreach ($data as $key => $value) {

    $carbon = new Carbon();
    ?>
    <br><br><h4  class='wow fadeInUp text-center text-uppercase monthDiv'>{{$carbon->month($key)->format('F')}}</h4>

    <div class="dashboard-item" id="pills-tabContent">
        <div class="tab-pane fade active show" id="pills-today" role="tabpanel" aria-labelledby="pills-today-tab">
            <div class="tabel-responsive">
                <table class="tabel-main wow fadeInUp cls cls-1" style="visibility: visible; animation-name: fadeInUp;" >
                    <thead>
                    <tr>
                        <th class="text-center">Date</th>
{{--                        <th class="text-center">ID</th>--}}
                        <th class="text-center">Coin</th>
                        <th class="text-center">Buy/sell</th>
                        <th class="text-center">Buy Price</th>
                        <th class="text-center">TakeProfit</th>
                        <th class="text-center">StopLoss</th>
{{--                        <th class="text-center">Status</th>--}}
                        @if($user->isAdmin())
                           <th>EDIT</th>
                        @endif
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($value as $key => $val)
                        @include('dashboard.forms.records')
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php } ?>
</div>

@include('footer')
<style>
    .rmrad{
        border-bottom-right-radius:0px;
        border-bottom-left-radius:0px;
    }
</style>
<script type="text/javascript">
    // $(document).on('click', '.btn', function() {
    //     var idd = $(this).attr('id');
    //     $('.btn').removeClass('active');
    //     $(this).addClass('active');
    //
    //     $('.btn').removeClass('rmrad');
    //     $(this).addClass('rmrad');
    //
    //     $('.h-25').hide();
    //     $(this).closest('.col-3').find('.h-25').show();
    //
    //     $('.cls').hide();
    //     $('.' + idd).fadeIn();
    // });
    //
    // $(document).on('click', '.btn', function() {
    //     var idd = $(this).attr('id');
    //
    //     $('.cls').hide();
    //     $('.' + idd).fadeIn();
    // });

    // $(document).ready(function() {
    //
    //     $(".hideMe").slideUp(3000);
    //
    // });

    // $(".main-input").on("change", function() {
    //     var fileName = $(this).val().split("\\").pop();
    //     $(this).siblings(".main-label").addClass("selected").html(fileName);
    // });


    // $(document).on('click', '#cls-2', function() {
    //     var dataRel = $('#cls-2').attr('data-rel');
    //     if (dataRel == true) {
    //         $('#cls-2').prop('disabled', true);
    //     } else {
    //         $('#cls-2').prop('disabled', false);
    //     }
    // });

    // $(document).on('click', 'button', function(e) {
    //     var currentId = $(this).attr('id');
    //     if (currentId == 'cls-1') {
    //         $('.monthDiv').css('display', 'block');
    //         $('.dashboard-item').css('display', 'block');
    //     } else {
    //         $('.monthDiv').css('display', 'none');
    //         $('.dashboard-item').css('display', 'none');
    //     }
    // });
</script>